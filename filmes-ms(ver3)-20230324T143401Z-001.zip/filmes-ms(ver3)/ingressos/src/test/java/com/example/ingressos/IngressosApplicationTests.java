package com.example.ingressos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IngressosApplicationTests {

	@Test
	void contextLoads() {
	}

}
